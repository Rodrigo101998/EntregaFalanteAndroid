package br.com.entregafalante
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.location.*
import android.Manifest
import android.os.*
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import java.util.Locale

class ProximityService:Service(),TextToSpeech.OnInitListener {
 private lateinit var tts:TextToSpeech;private lateinit var lm:LocationManager;private var ready=false
 private val last=mutableMapOf<String,Long>();private val channel="entrega_alertas"
 private val listener=object:LocationListener{override fun onLocationChanged(location:Location){check(location)}}
 override fun onCreate(){super.onCreate();canal()
  val n=NotificationCompat.Builder(this,channel).setSmallIcon(android.R.drawable.ic_menu_mylocation).setContentTitle("Entrega Falante ativo").setContentText("Verificando proximidade dos clientes").setOngoing(true).build()
  startForeground(1001,n);tts=TextToSpeech(this,this);lm=getSystemService(LOCATION_SERVICE) as LocationManager;track()
 }
 override fun onStartCommand(i:Intent?,f:Int,id:Int)=START_STICKY
 override fun onBind(i:Intent?):IBinder?=null
 override fun onInit(s:Int){ready=s==TextToSpeech.SUCCESS;if(ready)tts.language=Locale("pt","BR")}
 private fun track(){val fine=ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED
  val coarse=ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED
  if(!fine&&!coarse){stopSelf();return}
  try{if(fine)lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,5000L,15f,listener)else lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,10000L,50f,listener)}catch(_:SecurityException){stopSelf()}
 }
 private fun check(loc:Location){val a=try{JSONArray(getSharedPreferences("clientes",0).getString("lista","[]"))}catch(_:Exception){JSONArray()};val now=System.currentTimeMillis()
  for(i in 0 until a.length()){val o=a.optJSONObject(i)?:continue;val name=o.optString("nome","");val lat=o.optDouble("lat",Double.NaN);val lon=o.optDouble("lon",Double.NaN);if(name.isBlank()||lat.isNaN()||lon.isNaN())continue
   val d=FloatArray(1);Location.distanceBetween(loc.latitude,loc.longitude,lat,lon,d)
   val radius=getSharedPreferences("alertas",0).getInt("raio_metros",250).toFloat()
   val interval=getSharedPreferences("alertas",0).getInt("intervalo_min",30).toLong()*60*1000
   val key="$name:${"%.5f".format(java.util.Locale.US,lat)}:${"%.5f".format(java.util.Locale.US,lon)}"
   if(d[0]<=radius&&now-(last[key]?:0L)>interval){last[key]=now;if(ready)tts.speak(name,TextToSpeech.QUEUE_ADD,null,"p_$i")}
  }
 }
 private fun canal(){if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(channel,"Alertas de entrega",NotificationManager.IMPORTANCE_LOW))}
 override fun onDestroy(){try{lm.removeUpdates(listener)}catch(_:Exception){};if(::tts.isInitialized)tts.shutdown();super.onDestroy()}
}
