package br.com.entregafalante

import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.*

/**
 * Uses the public OSRM demo routing service to estimate driving order.
 * This endpoint is best-effort for prototypes, has no uptime guarantee,
 * and should not be used for high-volume production traffic.
 */
object RoutePlanner {
    data class Result(val ordered: List<Cliente>, val message: String)

    fun optimize(startLat: Double, startLon: Double, clients: List<Cliente>): Result {
        if (clients.size < 2) return Result(clients, "Cadastre pelo menos dois clientes.")
        if (clients.size > 90) return Result(nearest(startLat, startLon, clients), "Mais de 90 paradas: usada estimativa local.")
        return try {
            val coords = buildString {
                append("$startLon,$startLat")
                clients.forEach { append(";${it.lon},${it.lat}") }
            }
            val url = URL("https://router.project-osrm.org/table/v1/driving/$coords?annotations=duration,distance")
            val connection = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 12000
                requestMethod = "GET"
                setRequestProperty("User-Agent", "EntregaFalanteAndroid/0.3")
            }
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()
            val json = org.json.JSONObject(body)
            if (json.optString("code") != "Ok") return Result(nearest(startLat,startLon,clients), "Serviço de rota indisponível; ordem aproximada por GPS.")
            val distances = json.optJSONArray("distances") ?: return Result(nearest(startLat,startLon,clients), "Sem matriz de distâncias; ordem aproximada.")
            val remaining = clients.indices.toMutableList()
            val order = mutableListOf<Cliente>()
            var from = 0
            while (remaining.isNotEmpty()) {
                var best = remaining.first()
                var bestDist = Double.MAX_VALUE
                for (idx in remaining) {
                    val d = distances.optJSONArray(from)?.optDouble(idx + 1, Double.MAX_VALUE) ?: Double.MAX_VALUE
                    if (d < bestDist) { bestDist = d; best = idx }
                }
                order.add(clients[best])
                remaining.remove(best)
                from = best + 1
            }
            Result(order, "Ordem calculada por distância de condução estimada. Confira a navegação antes de sair.")
        } catch (_: Exception) {
            Result(nearest(startLat,startLon,clients), "Sem conexão com o serviço de rotas; ordem aproximada por GPS.")
        }
    }

    private fun nearest(startLat: Double, startLon: Double, clients: List<Cliente>): List<Cliente> {
        val rest = clients.toMutableList()
        val result = mutableListOf<Cliente>()
        var lat = startLat; var lon = startLon
        while (rest.isNotEmpty()) {
            val next = rest.minByOrNull { haversine(lat,lon,it.lat,it.lon) }!!
            result.add(next); rest.remove(next); lat=next.lat; lon=next.lon
        }
        return result
    }

    private fun haversine(a:Double,b:Double,c:Double,d:Double):Double {
        val x=Math.toRadians(c-a); val y=Math.toRadians(d-b)
        val h=sin(x/2).pow(2)+cos(Math.toRadians(a))*cos(Math.toRadians(c))*sin(y/2).pow(2)
        return 6371000.0*2*asin(sqrt(h.coerceIn(0.0,1.0)))
    }
}
