package br.com.entregafalante
import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.*
import androidx.core.app.ActivityCompat
import org.osmdroid.config.Configuration
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.events.MapEventsReceiver
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

data class Cliente(val nome:String,val lat:Double,val lon:Double)
class MainActivity:Activity(),TextToSpeech.OnInitListener {
 private lateinit var map:MapView; private lateinit var status:TextView; private lateinit var tts:TextToSpeech
 private val clientes=mutableListOf<Cliente>(); private var ponto:GeoPoint?=null; private var ttsOk=false
 private val prefs by lazy { getSharedPreferences("clientes",MODE_PRIVATE) }
 private var raioMetros= prefs.getInt("raio_metros",250)
 override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState)
  Configuration.getInstance().load(this,getSharedPreferences("osmdroid",MODE_PRIVATE)); Configuration.getInstance().userAgentValue=packageName
  tts=TextToSpeech(this,this); carregar()
  val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;setPadding(10,10,10,10);setBackgroundColor(Color.WHITE) }
  root.addView(TextView(this).apply { text="ENTREGA FALANTE";textSize=22f;gravity=Gravity.CENTER;setTextColor(Color.rgb(25,75,130)) })
  root.addView(TextView(this).apply { text="Toque no mapa para cadastrar o nome do cliente." })
  status=TextView(this).apply { text="${clientes.size}/100 clientes";setPadding(0,5,0,5) };root.addView(status)
  map=MapView(this).apply { setMultiTouchControls(true);controller.setZoom(13.0);controller.setCenter(GeoPoint(-9.38,-37.24));layoutParams=LinearLayout.LayoutParams(-1,0,1f) }
  map.overlays.add(MapEventsOverlay(object:MapEventsReceiver {
   override fun singleTapConfirmedHelper(p:GeoPoint):Boolean { ponto=p;nomeDialog();return true }
   override fun longPressHelper(p:GeoPoint)=false
  }));root.addView(map)
  val r1=LinearLayout(this);r1.addView(btn("Minha localização"){localizar()},lp());r1.addView(btn("Clientes"){listar()},lp());root.addView(r1)
  val r2=LinearLayout(this);r2.addView(btn("Iniciar alertas"){iniciar()},lp());r2.addView(btn("Parar alertas"){stopService(Intent(this,ProximityService::class.java));Toast.makeText(this,"Alertas parados",0).show()},lp());root.addView(r2)
  val r3=LinearLayout(this);r3.addView(btn("Testar voz"){falar("Próxima entrega: João da Silva")},lp());r3.addView(btn("Otimizar rota"){rota()},lp());root.addView(r3)
  val r4=LinearLayout(this);r4.addView(btn("Navegar"){rota()},lp());r4.addView(btn("Distância do aviso"){configurarRaio()},lp());root.addView(r4)
  val r5=LinearLayout(this);r5.addView(btn("Exportar clientes"){exportar()},lp());r5.addView(btn("Importar clientes"){importar()},lp());root.addView(r5)
  val r6=LinearLayout(this);r6.addView(btn("Configurações"){configuracoes()},lp());r6.addView(btn("Intervalo de alerta"){intervaloAlerta()},lp());root.addView(r6)
  val r7=LinearLayout(this);r7.addView(btn("Ajuda e permissões"){ajuda()},lp());r7.addView(btn("Apagar todos"){apagar()},lp());root.addView(r7)
  setContentView(root);desenhar();permissao()
 }
 private fun lp()=LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(2,2,2,2)}
 private fun btn(t:String,a:()->Unit)=Button(this).apply{text=t;textSize=12f;setOnClickListener{a()}}
 override fun onInit(s:Int){ttsOk=s==TextToSpeech.SUCCESS;if(ttsOk){val v=getSharedPreferences("app_config",0).getInt("voz",0);tts.language=when(v){1->Locale("pt","PT");2->Locale.getDefault();else->Locale("pt","BR")}}}
 private fun falar(s:String){if(ttsOk)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"cliente")}
 private fun nomeDialog(){val e=EditText(this).apply{hint="Nome do cliente"}
  AlertDialog.Builder(this).setTitle("Cadastrar cliente").setView(e).setNegativeButton("Cancelar",null).setPositiveButton("Salvar"){_,_->val n=e.text.toString().trim();val p=ponto
   if(n.isNotEmpty()&&p!=null&&clientes.size<100){clientes.add(Cliente(n,p.latitude,p.longitude));salvar();desenhar()}else Toast.makeText(this,"Digite um nome ou limite de 100 atingido",1).show()
  }.show()
 }
 private fun permissao(){if(ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION),42)}
 private fun iniciar(){if(clientes.isEmpty()){Toast.makeText(this,"Cadastre clientes primeiro",1).show();return}
  if(ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){permissao();return}
  if(android.os.Build.VERSION.SDK_INT>=33 && ActivityCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
   ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.POST_NOTIFICATIONS),43)
   Toast.makeText(this,"Permita notificações e toque em Iniciar alertas novamente.",Toast.LENGTH_LONG).show()
   return
  }
  if(android.os.Build.VERSION.SDK_INT>=29 && ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_BACKGROUND_LOCATION)!=PackageManager.PERMISSION_GRANTED){
   AlertDialog.Builder(this).setTitle("Permitir localização em segundo plano?")
    .setMessage("Para tentar avisar com a tela bloqueada, abra as permissões do app e escolha permitir localização o tempo todo, se essa opção existir no seu Android.")
    .setPositiveButton("Abrir permissões"){_,_->startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:$packageName")))}
    .setNegativeButton("Continuar sem isso",null).show()
   return
  }
  if(android.os.Build.VERSION.SDK_INT>=26)startForegroundService(Intent(this,ProximityService::class.java)) else startService(Intent(this,ProximityService::class.java))
  Toast.makeText(this,"Alertas iniciados: raio de 250 metros",1).show()
 }
 private fun intervaloAlerta(){
  val labels=arrayOf("Não repetir durante esta sessão","30 minutos","1 hora","2 horas")
  val vals=intArrayOf(24*60,30,60,120)
  val p=getSharedPreferences("alertas",0);val current=p.getInt("intervalo_min",30);val idx=vals.indexOf(current).let{if(it<0)1 else it}
  AlertDialog.Builder(this).setTitle("Repetição do aviso")
   .setSingleChoiceItems(labels,idx){d,w->p.edit().putInt("intervalo_min",vals[w]).apply();Toast.makeText(this,"Intervalo atualizado.",Toast.LENGTH_SHORT).show();d.dismiss()}
   .setNegativeButton("Cancelar",null).show()
 }
 private fun configuracoes(){
  val opcoes=arrayOf("Português (Brasil)","Português (Portugal)","Usar voz padrão do Android")
  val prefsApp=getSharedPreferences("app_config",MODE_PRIVATE)
  val atual=prefsApp.getInt("voz",0)
  AlertDialog.Builder(this).setTitle("Configurações de voz")
   .setSingleChoiceItems(opcoes,atual){dialog,which->
    prefsApp.edit().putInt("voz",which).apply()
    val loc=when(which){0->Locale("pt","BR");1->Locale("pt","PT");else->Locale.getDefault()}
    val result=tts.setLanguage(loc)
    Toast.makeText(this,if(result>=0)"Idioma da voz atualizado." else "Idioma não disponível no mecanismo de voz instalado.",Toast.LENGTH_LONG).show()
    dialog.dismiss()
   }.setPositiveButton("Concluir",null).show()
 }
 private fun configurarRaio(){
  val opcoes=arrayOf("100 metros","150 metros","250 metros","400 metros","500 metros","1 quilômetro")
  val valores=intArrayOf(100,150,250,400,500,1000)
  val selecionado=valores.indexOf(raioMetros).let{if(it<0)2 else it}
  AlertDialog.Builder(this).setTitle("Avisar a que distância?")
   .setSingleChoiceItems(opcoes,selecionado){dialog,which->
    raioMetros=valores[which];prefs.edit().putInt("raio_metros",raioMetros).apply()
    getSharedPreferences("alertas",MODE_PRIVATE).edit().putInt("raio_metros",raioMetros).apply()
    Toast.makeText(this,"Aviso configurado para ${opcoes[which]}",Toast.LENGTH_SHORT).show();dialog.dismiss()
   }.setNegativeButton("Cancelar",null).show()
 }
 private fun localizar(){try{val lm=getSystemService(LOCATION_SERVICE) as android.location.LocationManager
  val l=lm.getLastKnownLocation("gps")?:lm.getLastKnownLocation("network")
  if(l!=null){map.controller.animateTo(GeoPoint(l.latitude,l.longitude));map.controller.setZoom(17.0)}else Toast.makeText(this,"Ative o GPS e tente novamente",1).show()
 }catch(_:Exception){permissao()}}
 private fun desenhar(){map.overlays.removeAll{it is Marker};clientes.forEachIndexed{i,c->val m=Marker(map);m.position=GeoPoint(c.lat,c.lon);m.title=c.nome;m.snippet="Cliente ${i+1}";map.overlays.add(m)};map.invalidate();status.text="${clientes.size}/100 clientes cadastrados"}
 private fun editarNome(index:Int){
  if(index !in clientes.indices)return
  val c=clientes[index];val e=EditText(this).apply{setText(c.nome);setSingleLine(true)}
  AlertDialog.Builder(this).setTitle("Editar nome do cliente").setView(e)
   .setNegativeButton("Cancelar",null).setPositiveButton("Salvar"){_,_->
    val nome=e.text.toString().trim()
    if(nome.isNotEmpty()){clientes[index]=c.copy(nome=nome);salvar();desenhar()}
    else Toast.makeText(this,"O nome não pode ficar vazio.",Toast.LENGTH_SHORT).show()
   }.show()
 }
 private fun listar(){if(clientes.isEmpty())return;AlertDialog.Builder(this).setTitle("Clientes").setItems(clientes.map{it.nome}.toTypedArray()){_,i->val c=clientes[i];map.controller.animateTo(GeoPoint(c.lat,c.lon));AlertDialog.Builder(this).setItems(arrayOf("Falar nome","Editar nome","Excluir")){_,a->
   when(a){0->falar(c.nome);1->editarNome(i);2->{clientes.removeAt(i);salvar();desenhar()}}
  }.show()}.show()}
 private fun rota(){
  if(clientes.isEmpty()){Toast.makeText(this,"Cadastre clientes primeiro",1).show();return}
  val lm=getSystemService(LOCATION_SERVICE) as android.location.LocationManager
  val current=try{lm.getLastKnownLocation("gps")?:lm.getLastKnownLocation("network")}catch(_:Exception){null}
  val lat=current?.latitude ?: clientes.first().lat
  val lon=current?.longitude ?: clientes.first().lon
  status.text="Calculando ordem das entregas..."
  Thread {
   val result=RoutePlanner.optimize(lat,lon,clientes.toList())
   runOnUiThread {
    status.text="${clientes.size}/100 clientes cadastrados"
    AlertDialog.Builder(this).setTitle("Ordem sugerida da rota")
     .setMessage(result.ordered.mapIndexed{i,c->"${i+1}. ${c.nome}"}.joinToString("\n")+"\n\n"+result.message)
     .setPositiveButton("Abrir rota no Maps") { _,_ -> abrirRotaMultiparada(result.ordered) }
     .setNeutralButton("Navegar primeiro") { _,_ ->
      val c=result.ordered.firstOrNull() ?: return@setNeutralButton
      startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("google.navigation:q=${c.lat},${c.lon}&mode=d")))
     }.setNegativeButton("Fechar",null).show()
   }
  }.start()
 }
 private fun abrirRotaMultiparada(ordem:List<Cliente>){
  if(ordem.isEmpty())return
  // Google Maps URLs support a destination plus a limited set of intermediate waypoints.
  val visitaveis=ordem.take(10)
  val destino=visitaveis.last()
  val waypoints=visitaveis.dropLast(1).joinToString("%7C"){"${it.lat},${it.lon}"}
  val url=if(waypoints.isNotEmpty())
   "https://www.google.com/maps/dir/?api=1&destination=${destino.lat},${destino.lon}&waypoints=$waypoints&travelmode=driving"
  else "https://www.google.com/maps/dir/?api=1&destination=${destino.lat},${destino.lon}&travelmode=driving"
  startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url)))
  if(ordem.size>10)Toast.makeText(this,"O Google Maps recebe até 10 pontos nesta rota; os demais continuam cadastrados.",Toast.LENGTH_LONG).show()
 }

 private fun exportar(){
  val arr=JSONArray()
  clientes.forEach{arr.put(JSONObject().put("nome",it.nome).put("lat",it.lat).put("lon",it.lon))}
  val share=Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_SUBJECT,"Clientes - Entrega Falante");putExtra(Intent.EXTRA_TEXT,arr.toString())}
  startActivity(Intent.createChooser(share,"Exportar lista de clientes"))
 }

 private fun importar(){
  val input=EditText(this).apply{hint="Cole aqui o JSON exportado";minLines=4}
  AlertDialog.Builder(this).setTitle("Importar clientes").setMessage("Cole a lista exportada pelo Entrega Falante.")
   .setView(input).setNegativeButton("Cancelar",null).setPositiveButton("Importar"){_,_->
    try{
     val arr=JSONArray(input.text.toString());val novos=mutableListOf<Cliente>()
     for(i in 0 until arr.length()){
      val o=arr.getJSONObject(i);val nome=o.getString("nome").trim();val lat=o.getDouble("lat");val lon=o.getDouble("lon")
      if(nome.isNotEmpty()&&lat in -90.0..90.0&&lon in -180.0..180.0)novos.add(Cliente(nome,lat,lon))
     }
     if(clientes.size+novos.size>100)Toast.makeText(this,"A lista ultrapassaria o limite de 100 clientes.",Toast.LENGTH_LONG).show()
     else{clientes.addAll(novos);salvar();desenhar();Toast.makeText(this,"${novos.size} clientes importados.",Toast.LENGTH_LONG).show()}
    }catch(_:Exception){Toast.makeText(this,"Lista inválida. Use o texto JSON exportado pelo app.",Toast.LENGTH_LONG).show()}
   }.show()
 }

 private fun ajuda(){
  AlertDialog.Builder(this).setTitle("Como usar o Entrega Falante")
   .setMessage("1. Toque no mapa para cadastrar o ponto e o nome.\n2. Ajuste a distância do aviso.\\n3. Toque em Iniciar alertas e mantenha a localização ativada.\\n4. Para alertas com a tela bloqueada, permita notificações e localização nas configurações do Android e remova restrições de bateria se necessário.\n\nA versão atual não foi testada em aparelho real. O alerta depende do GPS, das permissões e das políticas de economia de bateria.")
   .setPositiveButton("Abrir configurações do app"){_,_->startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:$packageName")))}
   .setNegativeButton("Fechar",null).show()
 }
 private fun apagar(){AlertDialog.Builder(this).setTitle("Apagar todos os clientes?").setNegativeButton("Cancelar",null).setPositiveButton("Apagar"){_,_->clientes.clear();salvar();desenhar()}.show()}
 private fun salvar(){val a=JSONArray();clientes.forEach{a.put(JSONObject().put("nome",it.nome).put("lat",it.lat).put("lon",it.lon))};prefs.edit().putString("lista",a.toString()).apply()}
 private fun carregar(){try{val a=JSONArray(prefs.getString("lista","[]"));for(i in 0 until a.length()){val o=a.getJSONObject(i);clientes.add(Cliente(o.getString("nome"),o.getDouble("lat"),o.getDouble("lon")))}}catch(_:Exception){}}
 override fun onResume(){super.onResume();if(::map.isInitialized)map.onResume()}
 override fun onPause(){if(::map.isInitialized)map.onPause();super.onPause()}
 override fun onDestroy(){if(::tts.isInitialized)tts.shutdown();if(::map.isInitialized)map.onDetach();super.onDestroy()}
}
