plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
 namespace = "br.com.entregafalante"
 compileSdk = 35
 defaultConfig { applicationId = "br.com.entregafalante"; minSdk = 26; targetSdk = 35; versionCode = 9; versionName = "0.9.0" }
}
dependencies { implementation("org.osmdroid:osmdroid-android:6.1.20") }
