# Entrega Falante — protótipo Android v0.3

## Novidade desta versão
- Planejador de rota usando a API pública OSRM (matriz de distâncias de condução) para ordenar até 90 paradas, com fallback para distância GPS em linha reta.
- O serviço público OSRM é apenas para protótipo, não garante disponibilidade e pode ter limites. Para produção, integrar provedor de rotas com termos e limites adequados.
- Alertas por voz em raio fixo de 250 m no serviço em primeiro plano.

## Limitações
- Esta versão é código-fonte, não APK.
- O planejador foi adicionado como componente, mas ainda precisa ser ligado à interface e testado em dispositivo real antes de considerar a rota pronta.
- OSRM table estima distância entre pontos; não retorna uma rota de navegação multiparada. Para navegação, ainda é necessário abrir cada destino/rota no aplicativo de mapas.
- O Android pode impor permissões e restrições de bateria; funcionamento com tela bloqueada precisa ser validado em aparelho real.
- O endpoint público OSRM não é uma garantia de serviço para produção.

## Versão 0.4 — raio configurável
- Adicionado seletor de raio de alerta: 100, 150, 250, 400, 500 m ou 1 km.
- O serviço de alerta lê a distância escolhida nas preferências.
- Incluída declaração de permissão de localização em segundo plano. O fluxo de solicitação dessa permissão ainda deve ser tratado e testado em Android recente.
- Navegação multiparada real ainda não está pronta; o app só inicia navegação para um destino escolhido.

## Versão 0.5 — navegação com paradas e backup
- A ação de rota abre uma URL do Google Maps com destino e pontos intermediários para até 10 clientes por viagem (limite suportado depende do app/plataforma).
- Incluídas ações para exportar a lista de clientes como JSON via compartilhamento e importar JSON colado no app, para backup/migração.
- Clientes continuam limitados a 100 no cadastro local; não há sincronização automática em nuvem.
- Não foi compilado nem testado em aparelho real. A rota multiparada depende do suporte do Google Maps e pode variar por versão.

## Versão 0.6 — ajustes de voz e repetição
- Adicionadas preferências para voz pt-BR, pt-PT ou idioma padrão do Android.
- Adicionado intervalo de repetição do alerta: 30 min, 1 h, 2 h ou uma vez por sessão (implementado como 24 h por cliente).
- O mecanismo de voz e os idiomas disponíveis dependem do Android instalado.
- Não compilado/testado em aparelho real; a opção “uma vez por sessão” usa intervalo de 24 h como aproximação e não é um controle de sessão perfeito.

## Versão 0.7 — edição de cliente e ajuda
- Permite editar o nome de um cliente sem perder as coordenadas GPS.
- Adiciona tela de ajuda e atalho para as configurações do app, para revisar permissões.
- Alertas distinguem clientes com o mesmo nome usando também as coordenadas.
- Ainda é necessário compilar e testar em aparelho real; esta versão não é um APK pronto.

## Versão 0.8 — permissões em Android recente
- O app agora pede permissão de notificações em Android 13+ antes de iniciar o monitoramento.
- Em Android 10+, orienta abrir as configurações do aplicativo para habilitar localização em segundo plano, quando disponível.
- O comportamento e os nomes das opções variam conforme fabricante/versão do Android; validar em aparelho real é obrigatório.
- O projeto segue como código-fonte, não APK, e não foi compilado/testado neste ambiente.

## Versão 0.9 — revisão do código
- Corrigidas quebras de linha que estavam escritas literalmente nos arquivos Kotlin e impediriam a compilação.
- Atualizada a versão do aplicativo para 0.9.0.
- Ainda não foi possível compilar o APK neste ambiente porque não há Gradle/Android SDK configurado. O código precisa ser sincronizado e compilado no Android Studio para validar dependências e eventuais erros restantes.

## Gerar o APK em ambiente Android na nuvem

O projeto inclui o workflow `.github/workflows/android-apk.yml` para compilar o APK em um runner Linux com Java e Android SDK:

1. Envie o conteúdo deste ZIP para um repositório GitHub seu.
2. Abra a aba **Actions** do repositório e selecione **Build Android APK**.
3. Toque em **Run workflow** (ou envie um commit para `main`/`master`).
4. Quando terminar, abra a execução e baixe o artefato **EntregaFalante-debug-apk**.

**Importante:** esse workflow automatiza a tentativa de compilação; o APK só estará disponível se a compilação passar. O projeto ainda não foi compilado nem testado em aparelho, portanto não posso afirmar que o APK funciona até essa etapa ser concluída.


Versão de teste 0.9.1: targetSdk 34 para diagnóstico de compatibilidade; compileSdk permanece 35. Isso não garante a correção do encerramento inesperado.
